from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('survey.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS surveys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        surname TEXT,
        dob TEXT,
        age INTEGER,
        favourite_food TEXT,
        eat_out_rating INTEGER,
        watch_movies_rating INTEGER,
        watch_tv_rating INTEGER,
        listen_radio_rating INTEGER
    )''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def survey():
    return render_template('survey.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form.get('name')
    surname = request.form.get('surname')
    dob = request.form.get('dob')
    favourite_foods = request.form.getlist('food')
    eat_out = request.form.get('eat_out')
    watch_movies = request.form.get('watch_movies')
    watch_tv = request.form.get('watch_tv')
    listen_radio = request.form.get('listen_radio')

    if not all([name, surname, dob, eat_out, watch_movies, watch_tv, listen_radio]) or not favourite_foods:
        return "All fields are required and at least one food must be selected."

    age = int((datetime.now() - datetime.strptime(dob, "%Y-%m-%d")).days / 365.25)
    if age < 5 or age > 120:
        return "Age must be between 5 and 120."

    foods_str = ", ".join(favourite_foods)

    conn = sqlite3.connect('survey.db')
    c = conn.cursor()
    c.execute("INSERT INTO surveys (name, surname, dob, age, favourite_food, eat_out_rating, watch_movies_rating, watch_tv_rating, listen_radio_rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
              (name, surname, dob, age, foods_str, eat_out, watch_movies, watch_tv, listen_radio))
    conn.commit()
    conn.close()

    return redirect('/results')

@app.route('/results')
def results():
    conn = sqlite3.connect('survey.db')
    c = conn.cursor()
    c.execute("SELECT * FROM surveys")
    rows = c.fetchall()
    conn.close()

    if not rows:
        return render_template('results.html', message="No Surveys Available")

    total = len(rows)
    ages = [row[4] for row in rows]
    pizza_lovers = ["Pizza" in row[5] for row in rows]
    eat_out_avg = sum([row[6] for row in rows]) / total

    data = {
        "total": total,
        "avg_age": round(sum(ages) / total, 1),
        "oldest": max(ages),
        "youngest": min(ages),
        "pizza_percent": round((sum(pizza_lovers) / total) * 100, 1),
        "eat_out_avg": round(eat_out_avg, 1)
    }

    return render_template('results.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
